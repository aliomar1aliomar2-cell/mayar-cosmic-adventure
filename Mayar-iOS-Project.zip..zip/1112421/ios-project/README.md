# Mayar's Adventure — iOS build project (Capacitor)

هذا مجلد مشروع جاهز لبناء نسخة iOS على جهاز Mac. اللعبة نفسها كاملة داخل `www/`
(15 مرحلة، الرسومات، الأزرار الأربعة، المتجر، المهام، النجوم، الحفظ).

## المتطلبات
- Mac مع Xcode 15 أو أحدث (iOS 13+).
- Node.js 18+ و npm.
- حساب Apple Developer (مجاني للتجربة على جهازك، ومدفوع للنشر على App Store).

## خطوات البناء (5 دقائق)
```bash
cd mayar-ios
npm install
npx cap add ios          # ينشئ مشروع Xcode داخل ios/
npx cap sync ios         # ينسخ www/ إلى التطبيق
npx cap open ios         # يفتح Xcode
```

### داخل Xcode
1. اختر مشروع **App** → تبويب **Signing & Capabilities** → اختر Team الخاص بك،
   وغيّر Bundle Identifier إذا رغبت (الافتراضي `com.mayar.adventure`).
2. تبويب **Info** → أضف المفاتيح الموجودة في `Info-plist-keys.xml`
   (اتجاه أفقي فقط + ملء الشاشة + إخفاء شريط الحالة).
3. **Assets** → `AppIcon` → اسحب `AppIcon-1024.png` (مقاس 1024، بدون شفافية).
4. وصّل الآيفون بالكابل، اختر الجهاز في الأعلى، ثم **Run** ▶ للتجربة.
5. لإنتاج ملف IPA: **Product → Archive** ثم **Distribute App → Development/Ad Hoc/App Store**.

ملف IPA الناتج: يظهر في Organizer ويمكن تصديره إلى ملف `.ipa` للتوزيع
(يتطلب شهادة توقيع + Provisioning Profile من حساب Apple Developer).

## بديل سريع بدون Mac
- نسخة الويب المثبّتة (PWA) تعمل الآن على الآيفون: افتح الرابط في **Safari**،
  اضغط زر المشاركة → «إضافة إلى الشاشة الرئيسية». تعمل بملء الشاشة وأفقيًا وبدون إنترنت.
- أو استخدم خدمة Mac سحابي (Codemagic / Xcode Cloud / MacinCloud) وارفع هذا المجلد.

## ملاحظات تقنية
- الاتجاه الأفقي وملء الشاشة يأتيان من `Info.plist` وليس من الويب.
- التقدم يُحفظ في `localStorage` داخل التطبيق (WKWebView) ويبقى بين الجلسات.
- زر «FULLSCREEN» داخل اللعبة: على آيفون Safari لا يوجد Fullscreen API،
  لذلك يظهر تنبيه باستخدام «إضافة إلى الشاشة الرئيسية» بدلًا منه.
